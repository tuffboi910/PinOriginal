# Chroma

Chroma is an honest Android color-recipe builder and compatibility inspector. It extracts a palette from an imported image, supports HEX/RGB-style color recipes, saves intensity/brightness settings, previews tinted surfaces, and explains whether a target app can actually consume them.

## The important limitation

Android isolates signed applications. A normal app cannot change another app's private layouts, colors, or resources. Dynamic color only affects apps that voluntarily use it. Shizuku does not remove resource-overlay restrictions. Root Runtime Resource Overlays work only for resources the target exposes as `overlayable`, and must be maintained per device/app version. Chroma does not fake the result with screen filters and does not patch third-party APKs.

## Build

1. Open the project in Android Studio with JDK 17.
2. Install Android SDK 36.
3. Run the `app` configuration, or execute `gradle :app:assembleDebug` with Gradle 8.11.1.

GitHub Actions builds the APK on each push or manual run. Download `Chroma-debug-apk` from the run's **Artifacts** section.

## Compatibility

- Minimum Android 8 (API 26), target Android 16 (API 36).
- Stock One UI: Chroma can save/preview recipes and open Wallpaper & style. It cannot force Google, Chrome, Spotify, or Grok to accept a chosen color.
- Cooperating apps: can adopt the chosen recipe or Android dynamic color.
- Root/RRO: deliberately not automated because compatibility requires an explicit, overlayable resource map for each exact target version.

## Privacy

Image palette extraction runs on-device. No network permission is requested and no image is uploaded.

## License

Apache-2.0. See `LICENSE`.
