package app.chroma.android;
interface IChromaService {
    String exec(String command);
    void destroy();
}
