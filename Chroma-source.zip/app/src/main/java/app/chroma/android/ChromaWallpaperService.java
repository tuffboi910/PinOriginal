package app.chroma.android;

import android.app.WallpaperColors;
import android.graphics.*;
import android.os.Build;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import java.io.File;

public class ChromaWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine(){return new ChromaEngine();}
    private class ChromaEngine extends Engine {
        private final android.content.SharedPreferences prefs=getSharedPreferences("chroma",MODE_PRIVATE);
        @Override public void onVisibilityChanged(boolean visible){if(visible){draw();notifyColorsChanged();}}
        @Override public void onSurfaceChanged(SurfaceHolder h,int f,int w,int he){super.onSurfaceChanged(h,f,w,he);draw();}
        private void draw(){Canvas c=null;try{c=getSurfaceHolder().lockCanvas();if(c==null)return;int chosen=prefs.getInt("color",0xff287dff);File f=new File(getFilesDir(),"chroma_wallpaper.jpg");Bitmap b=f.exists()?BitmapFactory.decodeFile(f.getAbsolutePath()):null;if(b!=null){Rect src=new Rect(0,0,b.getWidth(),b.getHeight());float sr=(float)b.getWidth()/b.getHeight(),dr=(float)c.getWidth()/c.getHeight();if(sr>dr){int nw=(int)(b.getHeight()*dr),x=(b.getWidth()-nw)/2;src.set(x,0,x+nw,b.getHeight());}else{int nh=(int)(b.getWidth()/dr),y=(b.getHeight()-nh)/2;src.set(0,y,b.getWidth(),y+nh);}c.drawBitmap(b,src,new Rect(0,0,c.getWidth(),c.getHeight()),new Paint(Paint.FILTER_BITMAP_FLAG));}else{Paint p=new Paint();p.setShader(new LinearGradient(0,0,c.getWidth(),c.getHeight(),mix(chosen,Color.WHITE,.18f),mix(chosen,0xff01040d,.78f),Shader.TileMode.CLAMP));c.drawRect(0,0,c.getWidth(),c.getHeight(),p);}}finally{if(c!=null)getSurfaceHolder().unlockCanvasAndPost(c);}}
        @Override public WallpaperColors onComputeColors(){if(Build.VERSION.SDK_INT<27)return null;int p=prefs.getInt("color",0xff287dff);return new WallpaperColors(Color.valueOf(p),Color.valueOf(mix(p,Color.WHITE,.28f)),Color.valueOf(mix(p,Color.BLACK,.55f)));}
        private int mix(int a,int b,float t){return Color.rgb((int)(Color.red(a)*(1-t)+Color.red(b)*t),(int)(Color.green(a)*(1-t)+Color.green(b)*t),(int)(Color.blue(a)*(1-t)+Color.blue(b)*t));}
    }
}
