package app.chroma.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private EditText mainHex, secondHex; private View preview; private TextView status;
    private android.content.SharedPreferences prefs;
    private int primary=0xff287dff, secondary=0xff071a3d;
    private IChromaService remoteService;
    private String pendingCommand, pendingMessage;
    private Shizuku.UserServiceArgs serviceArgs;
    private final ServiceConnection serviceConnection=new ServiceConnection(){
        public void onServiceConnected(ComponentName name,IBinder binder){remoteService=IChromaService.Stub.asInterface(binder);executePending();}
        public void onServiceDisconnected(ComponentName name){remoteService=null;}
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);getWindow().setStatusBarColor(0xff07101f);getWindow().setNavigationBarColor(0xff07101f);
        prefs=getSharedPreferences("chroma",MODE_PRIVATE);primary=prefs.getInt("primary",primary);secondary=prefs.getInt("secondary",secondary);
        serviceArgs=new Shizuku.UserServiceArgs(new ComponentName(this,ChromaUserService.class)).processNameSuffix("color").debuggable(false).version(1);
        build();
    }
    private void build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(24),dp(34),dp(24),dp(28));root.setBackgroundColor(0xff07101f);scroll.addView(root);
        TextView title=label("Chroma",32,Color.WHITE);title.setTypeface(null,1);root.addView(title);root.addView(label("Pick two colors. Apply once.",14,0xff91a7c5));
        preview=new View(this);LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(-1,dp(190));pp.setMargins(0,dp(28),0,dp(20));root.addView(preview,pp);
        mainHex=input("Main HEX");mainHex.setText(hex(primary));root.addView(mainHex);
        secondHex=input("Secondary HEX");secondHex.setText(hex(secondary));root.addView(secondHex);
        LinearLayout.LayoutParams full=new LinearLayout.LayoutParams(-1,dp(54));full.setMargins(0,dp(8),0,0);
        Button apply=button("Apply system colors");apply.setOnClickListener(v->applyColors());root.addView(apply,full);
        LinearLayout pair1=new LinearLayout(this);Button swap=button("Swap");swap.setOnClickListener(v->{int x=primary;primary=secondary;secondary=x;sync();});Button save=button("Save");save.setOnClickListener(v->{if(read()){persist();note("Saved");}});pair1.addView(swap,half());pair1.addView(save,half());root.addView(pair1,new LinearLayout.LayoutParams(-1,dp(58)));
        LinearLayout pair2=new LinearLayout(this);Button reset=button("Reset colors");reset.setOnClickListener(v->{primary=0xff287dff;secondary=0xff071a3d;sync();});Button restore=button("Restore Android");restore.setOnClickListener(v->restoreSystem());pair2.addView(reset,half());pair2.addView(restore,half());root.addView(pair2,new LinearLayout.LayoutParams(-1,dp(58)));
        status=label("Ready",13,0xff91a7c5);status.setGravity(Gravity.CENTER);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.setMargins(0,dp(14),0,0);root.addView(status,sp);
        sync();setContentView(scroll);
    }
    private LinearLayout.LayoutParams half(){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(54),1);p.setMargins(dp(3),dp(8),dp(3),0);return p;}
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(Color.WHITE);e.setHintTextColor(0xff7186a5);e.setTextSize(16);e.setSingleLine();e.setPadding(dp(18),0,dp(18),0);e.setBackground(round(0xff111e32,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(56));p.setMargins(0,0,0,dp(10));e.setLayoutParams(p);return e;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setAllCaps(false);b.setStateListAnimator(null);b.setBackground(round(0xff17263e,16));return b;}
    private TextView label(String s,int size,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(c);v.setPadding(0,dp(3),0,dp(3));return v;}
    private GradientDrawable round(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),0x334f8fe8);return g;}
    private void sync(){mainHex.setText(hex(primary));secondHex.setText(hex(secondary));preview.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{primary,secondary}));persist();}
    private boolean read(){try{primary=parse(mainHex.getText().toString());secondary=parse(secondHex.getText().toString());preview.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{primary,secondary}));return true;}catch(Exception e){note("Use HEX like #287DFF");return false;}}
    private int parse(String s){String x=s.trim().replace("#","");if(x.length()!=6)throw new IllegalArgumentException();return 0xff000000|(int)Long.parseLong(x,16);}
    private String hex(int c){return String.format("#%06X",c&0xffffff);}
    private void persist(){prefs.edit().putInt("primary",primary).putInt("secondary",secondary).apply();}
    private void note(String s){status.setText(s);}
    private void applyColors(){
        if(!read())return;persist();
        if(!Shizuku.pingBinder()){note("Shizuku is not connected — open it, then return");return;}
        if(Shizuku.checkSelfPermission()!=android.content.pm.PackageManager.PERMISSION_GRANTED){Shizuku.requestPermission(73);note("Allow Shizuku, then tap Apply again");return;}
        String p=hex(primary).substring(1),s=hex(secondary).substring(1);
        String json="{\"android.theme.customization.system_palette\":\""+p+"\",\"android.theme.customization.accent_color\":\""+s+"\",\"android.theme.customization.color_source\":\"preset\"}";
        runShell("settings put secure theme_customization_overlay_packages '"+json+"'", "Applied — reopen compatible apps");
    }
    private void restoreSystem(){
        if(!Shizuku.pingBinder()){note("Shizuku is not connected — open it, then return");return;}
        if(Shizuku.checkSelfPermission()!=android.content.pm.PackageManager.PERMISSION_GRANTED){Shizuku.requestPermission(74);note("Allow Shizuku, then tap Restore again");return;}
        runShell("settings delete secure theme_customization_overlay_packages", "Android colors restored");
    }
    private void runShell(String command,String done){pendingCommand=command;pendingMessage=done;if(remoteService!=null)executePending();else{note("Connecting to Shizuku…");Shizuku.bindUserService(serviceArgs,serviceConnection);}}
    private void executePending(){if(remoteService==null||pendingCommand==null)return;final String command=pendingCommand,done=pendingMessage;pendingCommand=null;new Thread(()->{try{String result=remoteService.exec(command);runOnUiThread(()->note(result.startsWith("0|")?done:"Blocked by One UI"));}catch(Exception e){runOnUiThread(()->note("Shizuku connection failed — retry Apply"));remoteService=null;}}).start();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
}
