package app.chroma.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, content;
    private final int[] presets = {0xff287dff,0xff51b8ff,0xff6c5cff,0xffb8c9e8,0xff00d5ff};
    private int color;
    private float intensity, brightness;
    private boolean enabled;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state); getWindow().setStatusBarColor(0xff071020); getWindow().setNavigationBarColor(0xff050912);
        prefs=getSharedPreferences("chroma",MODE_PRIVATE);
        color=prefs.getInt("color",presets[0]); intensity=prefs.getFloat("intensity",.72f); brightness=prefs.getFloat("brightness",.35f); enabled=prefs.getBoolean("enabled",true);
        showHome();
    }
    private TextView text(String s,int sp,int c){ TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(c);v.setLetterSpacing(.01f);v.setPadding(dp(2),dp(6),dp(2),dp(6));return v; }
    private GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),blend(0x556caeff,color,.35f));return g;}
    private GradientDrawable gradient(int a,int b,float r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,blend(a,b,.45f),b});g.setCornerRadius(dp(r));g.setStroke(dp(1),0x88a9d8ff);return g;}
    private void base(String title){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(24),dp(20),dp(24));root.setBackgroundColor(0xff07101f);scroll.addView(root);
        TextView logo=text("Chroma",30,0xfff4f8ff);logo.setTypeface(null,1);root.addView(logo);
        TextView sub=text(title,13,0xff8da4c4);root.addView(sub);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(18),0,dp(18));root.addView(content);
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);String[] ns={"Home","Color","Apps","Info"};for(String n:ns){Button b=button(n);b.setOnClickListener(v->{if(n.equals("Home"))showHome();else if(n.equals("Color"))showPalette();else if(n.equals("Apps"))showApps();else showAbout();});LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(46),1);np.setMargins(dp(3),0,dp(3),0);nav.addView(b,np);}root.addView(nav);setContentView(scroll);
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xffe9f2ff);b.setTextSize(12);b.setAllCaps(false);b.setStateListAnimator(null);b.setBackground(bg(0xff15233a,16));return b;}
    private void card(String title,String body){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(16),dp(14),dp(16),dp(14));c.setBackground(bg(0xff101b2d,18));TextView t=text(title,16,Color.WHITE);t.setTypeface(null,1);c.addView(t);c.addView(text(body,13,0xffafbed2));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(12));content.addView(c,p);}
    private void showHome(){base("Real theming. Honest limits.");card("CURRENT CHROMA",String.format("#%06X  •  %s",color&0xffffff,enabled?"enabled":"disabled"));
        View sw=new View(this);sw.setBackground(bg(color,22));content.addView(sw,new LinearLayout.LayoutParams(-1,dp(112)));
        Button applyTheme=button("Apply to Android");applyTheme.setTextColor(Color.WHITE);applyTheme.setBackground(bg(color,16));applyTheme.setOnClickListener(v->applyLiveWallpaper());LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(56));ap.setMargins(0,dp(14),0,dp(8));content.addView(applyTheme,ap);
        Button toggle=button(enabled?"Disable preset":"Enable preset");toggle.setOnClickListener(v->{enabled=!enabled;save();showHome();});LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(55));bp.setMargins(0,dp(12),0,dp(12));content.addView(toggle,bp);
        card("WHAT IT CHANGES","Activates a real Chroma live wallpaper and reports your selected palette to Android's Material You engine. Supported Samsung/Google surfaces can use that palette.");card("HONEST LIMIT","Apps with hard-coded private themes—especially Spotify and Grok—can still ignore Android's palette. No non-root app can force those private resources.");
    }
    private void showPalette(){base("Build your chrome-blue palette.");TextView label=text(String.format("Selected  #%06X",color&0xffffff),20,Color.WHITE);content.addView(label);
        LinearLayout row=new LinearLayout(this);for(int p:presets){Button b=button("●");b.setTextColor(p);b.setTextSize(28);b.setOnClickListener(v->{color=p;save();showPalette();});row.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));}content.addView(row);
        EditText hex=input("HEX  •  287DFF");content.addView(hex);Button apply=button("Apply HEX ✦");apply.setOnClickListener(v->{try{String x=hex.getText().toString().replace("#","");color=0xff000000|(int)Long.parseLong(x,16);save();showPalette();}catch(Exception e){Toast.makeText(this,"That HEX code isn't valid",Toast.LENGTH_SHORT).show();}});content.addView(apply,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText rgb=input("RGB  •  40, 125, 255");rgb.setInputType(InputType.TYPE_CLASS_TEXT);content.addView(rgb);Button applyRgb=button("Apply RGB ✦");applyRgb.setOnClickListener(v->{try{String[] q=rgb.getText().toString().split(",");int r=Integer.parseInt(q[0].trim()),g=Integer.parseInt(q[1].trim()),b=Integer.parseInt(q[2].trim());if(r<0||r>255||g<0||g>255||b<0||b>255)throw new Exception();color=Color.rgb(r,g,b);save();showPalette();}catch(Exception e){Toast.makeText(this,"Use three numbers from 0 to 255",Toast.LENGTH_SHORT).show();}});content.addView(applyRgb,new LinearLayout.LayoutParams(-1,dp(50)));
        slider("Intensity",(int)(intensity*100),v->{intensity=v/100f;save();});slider("Surface brightness",(int)(brightness*100),v->{brightness=v/100f;save();});
        Button image=button("Extract palette from image");image.setOnClickListener(v->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE),42));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(55));ip.setMargins(0,dp(14),0,0);content.addView(image,ip);
        Button wall=button("Use current wallpaper color");wall.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=27){android.app.WallpaperColors wc=WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM);if(wc!=null&&wc.getPrimaryColor()!=null){color=wc.getPrimaryColor().toArgb();save();showPalette();return;}}Toast.makeText(this,"Wallpaper palette isn't available on this device",Toast.LENGTH_SHORT).show();});content.addView(wall,new LinearLayout.LayoutParams(-1,dp(55)));
        Button reset=button("Restore Chroma defaults");reset.setOnClickListener(v->{prefs.edit().clear().apply();color=presets[0];intensity=.72f;brightness=.35f;enabled=true;showPalette();});content.addView(reset,new LinearLayout.LayoutParams(-1,dp(55)));
    }
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(Color.WHITE);e.setHintTextColor(0xff7892b5);e.setSingleLine();e.setTextSize(14);e.setPadding(dp(18),0,dp(18),0);e.setBackground(bg(0xaa071329,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(9),0,dp(8));e.setLayoutParams(p);return e;}
    interface Change{void on(int v);}private void slider(String name,int value,Change cb){content.addView(text(name+"  "+value+"%",14,0xffb9c9df));SeekBar s=new SeekBar(this);s.setProgress(value);s.setProgressTintList(android.content.res.ColorStateList.valueOf(color));s.setThumbTintList(android.content.res.ColorStateList.valueOf(0xffd8edff));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){cb.on(p);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){showPalette();}});content.addView(s);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==42&&result==RESULT_OK&&data!=null){try(InputStream in=getContentResolver().openInputStream(data.getData())){Bitmap b=BitmapFactory.decodeStream(in);color=dominant(b);try(FileOutputStream out=openFileOutput("chroma_wallpaper.jpg",MODE_PRIVATE)){b.compress(Bitmap.CompressFormat.JPEG,94,out);}save();showPalette();Toast.makeText(this,"Image saved — tap APPLY TO ANDROID on Home",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Couldn't read that image",Toast.LENGTH_SHORT).show();}}}
    private void applyLiveWallpaper(){save();try{Intent i=new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,new ComponentName(this,ChromaWallpaperService.class));startActivity(i);}catch(Exception e){startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));}}
    private int dominant(Bitmap src){Bitmap b=Bitmap.createScaledBitmap(src,48,48,true);long r=0,g=0,bl=0,n=0;for(int y=0;y<48;y+=2)for(int x=0;x<48;x+=2){int c=b.getPixel(x,y);float[] h=new float[3];Color.colorToHSV(c,h);if(h[1]>.18&&h[2]>.18){r+=Color.red(c);g+=Color.green(c);bl+=Color.blue(c);n++;}}if(n==0)return presets[0];return Color.rgb((int)(r/n),(int)(g/n),(int)(bl/n));}
    private void showApps(){base("Compatibility on this phone.");app("Samsung system UI","Supported","Chroma supplies real wallpaper colors to Android. One UI may ask you to confirm a matching Color palette.");app("Google apps","Partial","Material You surfaces may follow Chroma; individual Google apps decide which surfaces participate.");app("Chrome","Partial","Some Android/Material surfaces may follow the system palette; web pages and private Chrome UI remain app-controlled.");app("Spotify","Unsupported","Spotify hard-codes its signed private theme and ignores Android dynamic color.");app("Grok","Unsupported","No public dynamic-color or external theme integration.");app("Cooperating apps","Supported","Apps using Android dynamic color receive Chroma's palette through the system.");card("ADVANCED MODE","Root + per-app runtime hooks could target private views, but every app update can break them and Android 16 integrity protections make that unsafe. Chroma does not patch APKs.");}
    private void app(String n,String status,String why){card(n+"  •  "+status,why);}
    private void showAbout(){base("How the tech actually works.");card("STOCK / NON-ROOT","Wallpaper colors and Material dynamic color are suggestions. Each app chooses whether to consume them. Chroma can create and preview recipes, not force them into another process.");card("SHIZUKU","Grants shell-level APIs, but it does not make non-overlayable third-party resources overlayable. Useful for supported system settings, not universal app recoloring.");card("ROOT + RRO","Can manage overlays for resources explicitly allowed by the target. There is no stable universal background resource, so overlays must be device/app/version specific.");card("ONE UI + ANDROID 16","Built with target SDK 36. Samsung Theme Park may theme supported system surfaces and Samsung apps, but cannot promise Google/Spotify/Grok internals.");Button settings=button("Open wallpaper & style");settings.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_SET_WALLPAPER));}catch(Exception e){Toast.makeText(this,"Wallpaper settings unavailable",Toast.LENGTH_SHORT).show();}});content.addView(settings,new LinearLayout.LayoutParams(-1,dp(54)));}
    private int blend(int a,int b,float t){return Color.rgb((int)(Color.red(a)*(1-t)+Color.red(b)*t),(int)(Color.green(a)*(1-t)+Color.green(b)*t),(int)(Color.blue(a)*(1-t)+Color.blue(b)*t));}
    private void save(){prefs.edit().putInt("color",color).putFloat("intensity",intensity).putFloat("brightness",brightness).putBoolean("enabled",enabled).apply();}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
