package app.chroma.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.text.InputType;
import java.io.InputStream;
import java.io.FileOutputStream;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, content;
    private final int[] presets = {0xff287dff,0xff51b8ff,0xff6c5cff,0xffb8c9e8,0xff00d5ff};
    private int color;
    private float intensity, brightness;
    private boolean enabled;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state); getWindow().setStatusBarColor(0xff071020); getWindow().setNavigationBarColor(0xff050912);
        prefs=getSharedPreferences("chroma",MODE_PRIVATE);
        color=prefs.getInt("color",presets[0]); intensity=prefs.getFloat("intensity",.72f); brightness=prefs.getFloat("brightness",.35f); enabled=prefs.getBoolean("enabled",true);
        showHome();
    }
    private TextView text(String s,int sp,int c){ TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(c);v.setLetterSpacing(sp>18?.08f:.02f);v.setPadding(dp(2),dp(6),dp(2),dp(6));return v; }
    private GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));g.setStroke(dp(1),blend(0x556caeff,color,.35f));return g;}
    private GradientDrawable gradient(int a,int b,float r){GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{a,blend(a,b,.45f),b});g.setCornerRadius(dp(r));g.setStroke(dp(1),0x88a9d8ff);return g;}
    private void base(String title){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(20),dp(18),dp(26));root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff03132e,blend(0xff090717,color,.12f),0xff02040b})); scroll.addView(root);
        TextView chip=text("  C / 01  •  PERSONAL COLOR ENGINE  ",10,0xffb9dcff);chip.setGravity(Gravity.CENTER);chip.setBackground(bg(0x661b3a68,30));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,dp(31));cp.setMargins(0,0,0,dp(13));root.addView(chip,cp);
        TextView logo=text("CHROMA ✦",32,0xffedf7ff);logo.setTypeface(null,1);logo.setShadowLayer(dp(14),0,0,color);root.addView(logo);
        TextView sub=text(title,13,0xff8db9eb);sub.setLetterSpacing(.1f);root.addView(sub);
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,dp(18),0,dp(18));root.addView(content);
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(4),dp(4),dp(4),dp(4));nav.setBackground(bg(0xaa0b1528,24));String[] ns={"HOME","COLOR","APPS","INFO"};for(String n:ns){Button b=button(n);b.setOnClickListener(v->{if(n.equals("HOME"))showHome();else if(n.equals("COLOR"))showPalette();else if(n.equals("APPS"))showApps();else showAbout();});LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,dp(48),1);np.setMargins(dp(2),0,dp(2),0);nav.addView(b,np);}root.addView(nav);setContentView(scroll);
    }
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xffeaf5ff);b.setTextSize(11);b.setLetterSpacing(.05f);b.setAllCaps(false);b.setStateListAnimator(null);b.setElevation(dp(2));b.setBackground(gradient(blend(0xff14223b,color,.18f),0xff091426,18));return b;}
    private void card(String title,String body){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(17),dp(15),dp(17),dp(15));c.setElevation(dp(5));c.setBackground(gradient(blend(0xff13213a,color,.19f*intensity),blend(0xff080d1b,color,.05f),24));TextView t=text(title,16,Color.WHITE);t.setTypeface(null,1);c.addView(t);c.addView(text(body,13,0xffb8c9df));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(13));content.addView(c,p);}
    private void showHome(){base("Real theming. Honest limits.");card("CURRENT CHROMA",String.format("#%06X  •  %s",color&0xffffff,enabled?"enabled":"disabled"));
        LinearLayout sw=new LinearLayout(this);sw.setGravity(Gravity.CENTER);sw.setElevation(dp(9));sw.setBackground(gradient(blend(color,0xffd9f0ff,.2f),blend(color,0xff030916,.72f),30));TextView orb=text("✦",48,Color.WHITE);orb.setShadowLayer(dp(18),0,0,Color.WHITE);sw.addView(orb);content.addView(sw,new LinearLayout.LayoutParams(-1,dp(148)));
        Button applyTheme=button("APPLY TO ANDROID  ✦");applyTheme.setOnClickListener(v->applyLiveWallpaper());LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-1,dp(58));ap.setMargins(0,dp(14),0,dp(8));content.addView(applyTheme,ap);
        Button toggle=button(enabled?"Disable preset":"Enable preset");toggle.setOnClickListener(v->{enabled=!enabled;save();showHome();});LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(55));bp.setMargins(0,dp(12),0,dp(12));content.addView(toggle,bp);
        card("WHAT IT CHANGES","Activates a real Chroma live wallpaper and reports your selected palette to Android's Material You engine. Supported Samsung/Google surfaces can use that palette.");card("HONEST LIMIT","Apps with hard-coded private themes—especially Spotify and Grok—can still ignore Android's palette. No non-root app can force those private resources.");
    }
    private void showPalette(){base("Build your chrome-blue palette.");TextView label=text(String.format("Selected  #%06X",color&0xffffff),20,Color.WHITE);content.addView(label);
        LinearLayout row=new LinearLayout(this);for(int p:presets){Button b=button("●");b.setTextColor(p);b.setTextSize(28);b.setOnClickListener(v->{color=p;save();showPalette();});row.addView(b,new LinearLayout.LayoutParams(0,dp(58),1));}content.addView(row);
        EditText hex=input("HEX  •  287DFF");content.addView(hex);Button apply=button("Apply HEX ✦");apply.setOnClickListener(v->{try{String x=hex.getText().toString().replace("#","");color=0xff000000|(int)Long.parseLong(x,16);save();showPalette();}catch(Exception e){Toast.makeText(this,"That HEX code isn't valid",Toast.LENGTH_SHORT).show();}});content.addView(apply,new LinearLayout.LayoutParams(-1,dp(50)));
        EditText rgb=input("RGB  •  40, 125, 255");rgb.setInputType(InputType.TYPE_CLASS_TEXT);content.addView(rgb);Button applyRgb=button("Apply RGB ✦");applyRgb.setOnClickListener(v->{try{String[] q=rgb.getText().toString().split(",");int r=Integer.parseInt(q[0].trim()),g=Integer.parseInt(q[1].trim()),b=Integer.parseInt(q[2].trim());if(r<0||r>255||g<0||g>255||b<0||b>255)throw new Exception();color=Color.rgb(r,g,b);save();showPalette();}catch(Exception e){Toast.makeText(this,"Use three numbers from 0 to 255",Toast.LENGTH_SHORT).show();}});content.addView(applyRgb,new LinearLayout.LayoutParams(-1,dp(50)));
        slider("Intensity",(int)(intensity*100),v->{intensity=v/100f;save();});slider("Surface brightness",(int)(brightness*100),v->{brightness=v/100f;save();});
        Button image=button("Extract palette from image");image.setOnClickListener(v->startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE),42));LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(-1,dp(55));ip.setMargins(0,dp(14),0,0);content.addView(image,ip);
        Button wall=button("Use current wallpaper color");wall.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=27){android.app.WallpaperColors wc=WallpaperManager.getInstance(this).getWallpaperColors(WallpaperManager.FLAG_SYSTEM);if(wc!=null&&wc.getPrimaryColor()!=null){color=wc.getPrimaryColor().toArgb();save();showPalette();return;}}Toast.makeText(this,"Wallpaper palette isn't available on this device",Toast.LENGTH_SHORT).show();});content.addView(wall,new LinearLayout.LayoutParams(-1,dp(55)));
        Button reset=button("Restore Chroma defaults");reset.setOnClickListener(v->{prefs.edit().clear().apply();color=presets[0];intensity=.72f;brightness=.35f;enabled=true;showPalette();});content.addView(reset,new LinearLayout.LayoutParams(-1,dp(55)));
    }
    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(Color.WHITE);e.setHintTextColor(0xff7892b5);e.setSingleLine();e.setTextSize(14);e.setPadding(dp(18),0,dp(18),0);e.setBackground(bg(0xaa071329,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(54));p.setMargins(0,dp(9),0,dp(8));e.setLayoutParams(p);return e;}
    interface Change{void on(int v);}private void slider(String name,int value,Change cb){content.addView(text(name+"  "+value+"%",14,0xffb9c9df));SeekBar s=new SeekBar(this);s.setProgress(value);s.setProgressTintList(android.content.res.ColorStateList.valueOf(color));s.setThumbTintList(android.content.res.ColorStateList.valueOf(0xffd8edff));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar b,int p,boolean f){cb.on(p);}public void onStartTrackingTouch(SeekBar b){}public void onStopTrackingTouch(SeekBar b){showPalette();}});content.addView(s);}
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==42&&result==RESULT_OK&&data!=null){try(InputStream in=getContentResolver().openInputStream(data.getData())){Bitmap b=BitmapFactory.decodeStream(in);color=dominant(b);try(FileOutputStream out=openFileOutput("chroma_wallpaper.jpg",MODE_PRIVATE)){b.compress(Bitmap.CompressFormat.JPEG,94,out);}save();showPalette();Toast.makeText(this,"Image saved — tap APPLY TO ANDROID on Home",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Couldn't read that image",Toast.LENGTH_SHORT).show();}}}
    private void applyLiveWallpaper(){save();try{Intent i=new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,new ComponentName(this,ChromaWallpaperService.class));startActivity(i);}catch(Exception e){startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));}}
    private int dominant(Bitmap src){Bitmap b=Bitmap.createScaledBitmap(src,48,48,true);long r=0,g=0,bl=0,n=0;for(int y=0;y<48;y+=2)for(int x=0;x<48;x+=2){int c=b.getPixel(x,y);float[] h=new float[3];Color.colorToHSV(c,h);if(h[1]>.18&&h[2]>.18){r+=Color.red(c);g+=Color.green(c);bl+=Color.blue(c);n++;}}if(n==0)return presets[0];return Color.rgb((int)(r/n),(int)(g/n),(int)(bl/n));}
    private void showApps(){base("Compatibility on this phone.");app("Samsung system UI","Supported","Chroma supplies real wallpaper colors to Android. One UI may ask you to confirm a matching Color palette.");app("Google apps","Partial","Material You surfaces may follow Chroma; individual Google apps decide which surfaces participate.");app("Chrome","Partial","Some Android/Material surfaces may follow the system palette; web pages and private Chrome UI remain app-controlled.");app("Spotify","Unsupported","Spotify hard-codes its signed private theme and ignores Android dynamic color.");app("Grok","Unsupported","No public dynamic-color or external theme integration.");app("Cooperating apps","Supported","Apps using Android dynamic color receive Chroma's palette through the system.");card("ADVANCED MODE","Root + per-app runtime hooks could target private views, but every app update can break them and Android 16 integrity protections make that unsafe. Chroma does not patch APKs.");}
    private void app(String n,String status,String why){card(n+"  •  "+status,why);}
    private void showAbout(){base("How the tech actually works.");card("STOCK / NON-ROOT","Wallpaper colors and Material dynamic color are suggestions. Each app chooses whether to consume them. Chroma can create and preview recipes, not force them into another process.");card("SHIZUKU","Grants shell-level APIs, but it does not make non-overlayable third-party resources overlayable. Useful for supported system settings, not universal app recoloring.");card("ROOT + RRO","Can manage overlays for resources explicitly allowed by the target. There is no stable universal background resource, so overlays must be device/app/version specific.");card("ONE UI + ANDROID 16","Built with target SDK 36. Samsung Theme Park may theme supported system surfaces and Samsung apps, but cannot promise Google/Spotify/Grok internals.");Button settings=button("Open wallpaper & style");settings.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_SET_WALLPAPER));}catch(Exception e){Toast.makeText(this,"Wallpaper settings unavailable",Toast.LENGTH_SHORT).show();}});content.addView(settings,new LinearLayout.LayoutParams(-1,dp(54)));}
    private int blend(int a,int b,float t){return Color.rgb((int)(Color.red(a)*(1-t)+Color.red(b)*t),(int)(Color.green(a)*(1-t)+Color.green(b)*t),(int)(Color.blue(a)*(1-t)+Color.blue(b)*t));}
    private void save(){prefs.edit().putInt("color",color).putFloat("intensity",intensity).putFloat("brightness",brightness).putBoolean("enabled",enabled).apply();}
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
