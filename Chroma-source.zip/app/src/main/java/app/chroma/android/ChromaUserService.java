package app.chroma.android;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ChromaUserService extends IChromaService.Stub {
    public ChromaUserService(){}
    @Override public String exec(String command){
        try{
            java.lang.Process p=Runtime.getRuntime().exec(new String[]{"sh","-c",command});
            BufferedReader er=new BufferedReader(new InputStreamReader(p.getErrorStream()));
            int code=p.waitFor();String message=er.readLine();
            return code+"|"+(message==null?"":message);
        }catch(Exception e){return "1|"+e.getMessage();}
    }
    @Override public void destroy(){System.exit(0);}
}
