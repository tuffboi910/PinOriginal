plugins { id("com.android.application") }

android {
    namespace = "app.chroma.android"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.chroma.android"
        minSdk = 26
        targetSdk = 36
        versionCode = 3
        versionName = "1.3.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}
