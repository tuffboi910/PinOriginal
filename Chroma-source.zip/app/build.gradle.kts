plugins { id("com.android.application") }

dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
}

android {
    namespace = "app.chroma.android"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.chroma.android"
        minSdk = 26
        targetSdk = 36
        versionCode = 5
        versionName = "1.4.1"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}
