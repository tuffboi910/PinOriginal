plugins { id("com.android.application") }

dependencies {
    implementation("dev.rikka.shizuku:api:12.2.0")
    implementation("dev.rikka.shizuku:provider:12.2.0")
}

android {
    namespace = "app.chroma.android"
    compileSdk = 36

    defaultConfig {
        applicationId = "app.chroma.android"
        minSdk = 26
        targetSdk = 36
        versionCode = 4
        versionName = "1.4.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }
}
